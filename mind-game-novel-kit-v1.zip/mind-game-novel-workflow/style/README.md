# Style

逻辑剧情通过后，本目录保存：

- `style-bible.md`
- `character-voice-cards.md`
- calibration scene 初稿 / 修订稿

风格文件不得覆盖剧情权威文件。任何 prose 或 deslop 操作都不能改变事实、证据、伏笔、人物认知与 scene outcome。

