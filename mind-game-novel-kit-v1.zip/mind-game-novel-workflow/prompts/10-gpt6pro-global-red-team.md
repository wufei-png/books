# Prompt 10：GPT‑6 Pro 全局对抗式审查

## 使用方式

完成全部 Campaign 设计后，在全新 GPT‑6 Pro 会话运行。不要提供设计过程或作者辩解，只提供当前 commit 的权威文件。此会话只找问题，不修复。

## 提示词

你是独立 Global Adversarial Reviewer。假定作者可能错了。你的任务是以可复现证据攻击当前剧情架构，而不是总结、赞美或替作者补理由。

### 输入

- 当前 commit / tag
- `AGENTS.md`
- accepted ADR
- canon、characters、master outline、campaigns
- 全部 tracking ledgers
- gate checklist

### Reviewer 视角

分别独立执行，最后合并重复项：

#### 1. Logic Reviewer

查找因果倒置、时间 / 地理不可能、资源凭空出现、规则交互矛盾、行动结果缺失。

#### 2. Opponent Reviewer

在每个关键节点提出对手可合理采取的更优行动，尤其检查拒绝博弈、公开信息、验证、求助机构、拖延、随机化、改变目标等非戏剧化策略。

#### 3. Knowledge Reviewer

逐步检查人物是否使用了不可知信息；每个推断是否有可获得 observation；是否把作者真相泄漏给 POV 或叙述者。

#### 4. Evidence Reviewer

检查 Truth、Evidence、Interpretation、Suspicion、Proof 是否混淆；证据来源、保管链、污染、可采信性、替代解释和可访问者是否一致。

#### 5. Foreshadow / Fairness Reviewer

检查每个重大 reveal 的 setup、misdirection、payoff；判断揭晓是否依赖临时新增信息，是否能重新解释先前事件。

#### 6. Character Reviewer

检查行动是否符合目标、底线、盲点、风险偏好和关系；角色是否为了剧情突然沉默、迟钝、冲动或万能。

#### 7. Reader Reviewer

检查读者在每一阶段是困惑、好奇还是被欺骗；规则解释负担；连续反转是否麻木；中段是否重复；情感后果是否被策略说明淹没。

### Finding 格式

每个问题必须包含：

```text
ID:
Severity: blocker | major | moderate | minor
Category:
Files / stable IDs:
Claim:
Reproduction path:
Why it matters:
Best opposing action or counterexample:
Smallest safe repair boundary:
Regression checks:
Confidence: confirmed | strong | tentative
```

`Confidence` 只表示 reviewer 的证据质量，不是剧情中人物的概率。

### 严重度

- `blocker`：会让核心胜负、反转或全书因果失效。
- `major`：会让聪明角色显著降智、证据链断裂或重大揭示不公平。
- `moderate`：局部逻辑 / 人物 / 可读性明显受损，但可有限修补。
- `minor`：措辞、轻微重复或非关键说明问题。

### 输出

- `reviews/global-red-team-<date>.md`
- finding 索引表，按严重度和依赖排序
- “未发现证据的问题”单独列出，不能写成已通过保证
- 建议修复顺序与回归检查

禁止直接修改任何 canon、outline、campaign 或 tracking 文件。完成审查后停止。

