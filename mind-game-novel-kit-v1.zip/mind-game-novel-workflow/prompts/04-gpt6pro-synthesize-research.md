# Prompt 04：GPT‑6 Pro 综合研究，生成设计约束

## 使用方式

在新的 GPT‑6 Pro 网页会话中使用。附加两份冻结研究报告和本提示词。不要附加任何未选定的小说构想。

## 提示词

你是本项目的 Research Synthesizer。请读取：

- `research/mind-game-design.md`
- `research/ai-fiction-engineering.md`

本轮任务是把两份独立研究转化为后续创作可执行的约束与工作流。**禁止开始原创小说设计**：不得提出人物、世界观、能力、核心诡计、结局或章节。

### 需要完成

1. 提取两份报告中证据最强、最适用于本项目的结论。
2. 标记二者的冲突、空白、未经证明的外推和时间敏感项。
3. 将“理论建议”转化为可检查的创作约束。
4. 确定 Git 文件的权威顺序、阶段门、会话分工和 handoff 格式。
5. 确定最小 tracking 字段；避免为了完整而过度建模。
6. 给出要直接复用、借鉴、自研和暂缓的工程决策。
7. 明确哪些决定必须由人类确认。

### 输出文件 1：`research/synthesis.md`

至少包含：

- 已接受的研究结论（附来源回链到两份报告的章节）
- 有条件接受的结论
- 暂不采用的结论及原因
- 创作硬约束
- 创作软偏好
- 反模式清单
- 最小数据模型
- 推荐阶段与阶段门
- 仍需人工决定的问题
- 研究更新触发条件

### 输出文件 2：`decisions/ADR-0001-creative-engineering-workflow.md`

采用以下结构：

```markdown
# ADR-0001: Creative and engineering workflow

- Status: proposed
- Date: YYYY-MM-DD
- Research baseline: research-baseline-v1

## Context
## Decision
## Alternatives considered
## Consequences
## Human approval required
## Revisit triggers
```

### 输出要求

- 只使用输入报告支持的结论；推论要显式标记。
- 不为了统一而掩盖研究冲突。
- 不引用聊天记忆中的内容。
- 以“文件清单 + 每个文件完整内容 + handoff manifest”结束。
- 若输入不足，列出阻塞项并停止，不得自行发明研究结论。

停止条件：工作流与约束可供下一轮概念生成使用。不得继续生成概念。

