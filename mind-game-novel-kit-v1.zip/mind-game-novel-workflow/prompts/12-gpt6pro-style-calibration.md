# Prompt 12：GPT‑6 Pro 文风与样章校准

## 使用方式

仅在 plot logic 通过全局红队和回归检查后使用。新开 GPT‑6 Pro 会话。附加 canon、相关人物、一个已完成 campaign、Style 模板；不要附加整本研究报告，改用 `research/synthesis.md`。

## 提示词

你是中文小说 Style Architect 与 Scene Writer。本轮目标是确定可持续执行的文风系统，并用一段测试场景校准；不是正式开始全书连载。

### 风格边界

- 不模仿任何在世作者的具体文风。
- 只定义高层特征：冷静 / 克制 / 高信息密度 / 对话主导 / 少解释 / 场景内呈现 / 叙述距离 / 句长与节奏变化 / 省略与潜台词。
- 每个主要人物必须有可观察的 idiolect，但避免方言标签化和口头禅滥用。
- 智斗对白至少同时承担两项功能：表面意义 + 试探 / 隐瞒 / 诱导 / 权力关系 / 情感防御。
- 推理必须可理解，但叙述者不替读者总结每个动作的意义。

### 任务 1：Style Bible

定义：

- 叙事人称与默认 POV
- narrative distance
- 心理描写允许与禁止的方式
- 场景感官选择原则
- 对话 / 动作 / 内心比例的原则（不必伪造固定百分比）
- 紧张、调查、亲密、失败、揭晓等场景的节奏差异
- 比喻和抽象句的使用边界
- 章节开头 / 结尾的变体策略
- AI-tell blacklist
- 事实 / 证据 / 伏笔保护规则

### 任务 2：Character Voice Cards

为测试场景涉及人物分别定义：词汇层级、句式、回避方式、说谎方式、施压方式、情绪泄漏方式、沉默的作用、绝不会说的句子类型。不要写成刻板口头禅列表。

### 任务 3：测试场景

从已批准 campaign 中选择一个不会泄露全书最大反转、但同时包含策略与情感压力的场景。先写 scene contract：

- POV
- scene goal
- visible conflict
- hidden strategic conflict
- entering knowledge state
- exiting knowledge state
- facts that must not change
- clues that must remain ambiguous

然后写 1500–2500 中文字初稿。

### 任务 4：独立自检与一次修订

按以下维度逐项指出具体句段问题：

- 是否像小说而非剧情说明书
- 是否过度解释
- 是否人物同声
- 是否存在工整三段式、连续精致比喻、平均句长、空洞总结
- 智斗是否可理解
- 信息是否过少 / 过多
- POV 是否使用不可知信息
- 修改是否会伤害伏笔

修订一次。只进行必要修改，不追求把每句都磨亮。

### 输出文件

- `style/style-bible.md`
- `style/character-voice-cards.md`
- `style/calibration-scene-v1.md`
- `style/calibration-scene-v2.md`
- `reviews/style-calibration-review.md`
- `decisions/ADR-0005-style-baseline.md`

在 review 中列出 v1 → v2 的主要差异及其理由。ADR 为 `proposed`，等待用户判断“是否真的愿意继续读”。

禁止改动剧情事实、证据、规则、伏笔、人物认知状态和 scene outcome。

