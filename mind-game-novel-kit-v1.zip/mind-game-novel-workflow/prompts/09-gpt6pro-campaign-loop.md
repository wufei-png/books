# Prompt 09：GPT‑6 Pro 单场智斗设计循环

## 使用方式

**每个 CAMP-ID 开一个全新 GPT‑6 Pro 会话。** 替换下方变量，并只附加本场需要的权威文件。不要把其他战役的完整聊天记录一起带入。

## 会话变量

```text
CAMPAIGN_ID = CAMP-__
PREVIOUS_STATE_COMMIT = <git commit or tag>
TARGET_FILES = <本场允许新增/修改的文件>
```

## 提示词

你是 `CAMPAIGN_ID` 的对抗式剧情工程师。请以 `PREVIOUS_STATE_COMMIT` 对应的 Git 文件为唯一事实源。

### 必须读取

- `AGENTS.md`
- accepted ADR
- `story/canon/`
- 本场涉及的 `story/characters/`
- `story/outline/master-outline.md`
- `story/outline/campaign-map.md` 中的 `CAMPAIGN_ID`
- 前一战役结束后的 `tracking/` 状态
- 与本场直接相关的 foreshadow / promise

若输入互相矛盾，停止并输出冲突报告，不自行修复。

### 阶段 1：冻结初始状态

明确列出：

- Author Truth
- Reader State
- A / B / Wildcard 分别 knows、strongly infers、suspects、unknown、falsely believes 什么
- 每方可访问的证据、资源、关系和制度权限
- 每方目标、底线、风险偏好
- 时间、地理、规则与社会约束

不得使用模糊的“他大概知道”。每个状态回链稳定 ID。

### 阶段 2：提出行动空间

分别站在每一方自身视角，提出 3–5 个当时可行的行动。对每项说明：

- 所依据的信息
- 预期收益
- 风险和成本
- 对手可观察到什么
- 会产生或破坏什么证据
- 为什么该人物会 / 不会选择

不要先写作者想要的结果再倒推人物。

### 阶段 3：选择 opening move

根据人物、目标和风险偏好选择，而不是根据“最戏剧化”。随后建立完整链：

`Move → Observable Signal → Opponent Interpretation → Countermove → New Evidence → Knowledge Update → Counter-countermove → Turning Point → Cost → Result`

每一步都记录：Actor、Goal、Available Information、Beliefs、Assumptions、Action、Observed By、Intended Inference、Actual Inference、Alternatives Rejected、Cost、State Delta。

### 阶段 4：最强对手测试

暂停作者推进，站在受攻击方视角回答：

1. 最快识破路径是什么？
2. 最稳妥而非最聪明的反制是什么？
3. 是否应拒绝进入对方设定的博弈？
4. 是否可以公开信息、寻求机构协助或改变规则环境？
5. 是否存在成本更低的替代行动？
6. 如果没有采取该行动，是因为不知道、不能、代价太高，还是人物盲点？

任何“他不会想到”都必须由已有性格与信息支持。

### 阶段 5：公平性与可读性

检查：

- 读者是否获得理解关键动作所需的信息；
- 是否过早泄漏真相；
- 误导是否来自合理解释而非删掉 POV 已知信息；
- 转折能否回溯到至少两个既有细节；
- 规则解释能否通过行动呈现；
- 场面是否具有具体可视行动，而非全是脑内说明。

### 阶段 6：结束状态

输出明确 delta：

- Truth（通常不因角色行为改变，除非世界事实真的变化）
- Knowledge
- False Belief
- Evidence / Chain of Custody
- Reader State
- Resources
- Relationships
- Promise / Foreshadow
- Unresolved Questions

胜负可以是：一方获胜、双方局部获益、表面胜者与实际获益者不同；但必须有成本并改变下一场的可行策略。

### 输出文件

- `story/campaigns/CAMP-__-<slug>.md`
- 对 `tracking/*.yaml` 的明确 patch 建议
- `reviews/CAMP-__-self-audit.md`
- `templates/handoff-manifest.md` 格式的 handoff

### 禁止事项

- 不修改 master plot、核心规则或人物底线来迁就本场；若必须改，提出 ADR，停止本场。
- 不用新能力、未公开规则、巧合、对手降智或“早已算到一切”决定胜负。
- 不写正式正文；可写极短的行为示例帮助理解，但不能用文风掩盖逻辑。
- 不继续下一个 campaign。

