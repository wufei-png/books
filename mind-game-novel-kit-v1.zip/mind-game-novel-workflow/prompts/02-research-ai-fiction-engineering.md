# Prompt 02：AI 长篇小说工程与工具 Deep Research

## 使用方式

在与 Prompt 01 完全独立的新 Deep Research 会话中使用。本轮只研究长篇生成工程、工具和质量控制，不设计小说剧情。

## 提示词

你正在执行一项独立技术研究：如何使用当前 LLM、Agent、Git 与结构化记忆，稳定辅助创作高质量中文长篇智斗小说。

唯一优化目标是最终小说质量；成本、速度与工程简洁度是次级目标。但不得为了显得先进而引入无必要的数据库、多 Agent 或框架。

本轮不设计任何具体小说概念、人物、反转或章节。

### 一、研究长篇生成方法

至少核查：

- Re3
- DOC / `facebookresearch/doc-storygen-v2`
- DOME
- StoryWriter 或同类层级式生成研究
- GOAT Storytelling Agent
- ConStory-Bench / ConStory-Checker

主动寻找研究执行日更合适的论文、benchmark 或公开实现。

重点比较：

- hierarchical / dynamic outlining
- recursive planning
- retrieval memory
- story bible
- temporal knowledge graph
- character state
- fact extraction
- continuity checking
- reranking / revision
- long-context 与结构化记忆的真实边界
- 中段一致性衰减
- 自动指标与人类叙事质量之间的偏差

说明每项方法的证据强度、实验任务与对“中文高复杂度智斗小说”的可迁移性。不要把论文在短故事或简单 benchmark 上的结果直接外推为已证明适用于长篇小说。

### 二、实际检查 GitHub / Skills / 工具

至少实际检查下列项目在研究执行日的状态：

- `zenstory-ai/oh-story-claudecode`
- `thimbleberrysystems/WordBird`
- `NekoStash/AeonEchoes`
- `iLearn-Lab/NovelClaw`
- `GOAT-AI-lab/GOAT-Storytelling-Agent`
- `facebookresearch/doc-storygen-v2`
- ConStory-Bench 对应官方仓库
- `SNLCC/novel-writer`
- `huxiuzh-ops/huxiuzhi-novel-agent`

并主动寻找可能更好的项目。

不能只看 README 宣传。尽量检查：

- 目录与关键实现文件
- 最近 commit / release / issue
- license
- 安装与运行方式
- 真实数据模型
- 是否只有 prompts，还是有可执行校验
- Codex / Claude Code 适配方式
- 自定义 Skill 扩展边界
- 中文正文支持是否有证据

### 三、评价维度

至少包括：

- Story Bible
- hierarchical outline / scene planning
- character / knowledge state
- timeline
- truth / evidence / proof
- foreshadowing / plot-thread tracking
- retrieval / knowledge graph
- continuity audit
- multi-agent review
- Chinese prose / dialogue / style control
- voice exemplars
- de-AI / deslop 的保护边界
- human-in-the-loop
- Git friendliness
- maturity / activity / license

不要机械算综合分。明确回答：

1. 哪个项目最值得直接作为底座？
2. 哪些只值得借鉴单个模块或数据结构？
3. 哪些方法已过时、证据不足或不适合本目标？
4. 应该直接使用、fork、cherry-pick 思想，还是自建轻量层？
5. Oh Story 是否适合作为底座；若适合，需要补哪些智斗专用能力？

### 四、设计推荐工程架构

至少评估下列专用 Skill 是否应拆分：

- `mind-game-architect`
- `knowledge-state-tracker`
- `mind-game-auditor`
- `foreshadowing-auditor`
- `adversarial-plot-reviewer`
- `story-deslop` 或等价最小润色阶段

说明哪些职责必须隔离，哪些合并更好。对每个阶段给出：Input、Output、Allowed Changes、Forbidden Changes、Required Context、Validation Criteria。

推荐一个 Git-friendly 的目录与数据方案。优先 Markdown + YAML / JSONL，除非有明确理由，不引入数据库。必须考虑：

- 稳定 ID
- Git diff 可读性
- canon 锁定与变更记录
- schema version
- 跨文件引用
- 机器校验
- 人工审阅
- 对 20–40 万字项目的扩展性

### 五、去 AI 味与文风工程

目标不是欺骗 detector，而是提高小说质量。研究并评价：

- story-deslop / humanizer / deslop skills
- style bible
- voice fingerprint / voice exemplars
- character idiolect
- scene POV / narrative distance
- rhythm / subtext / omission

明确哪些方法会把文本改成“干净但平庸”，以及如何保证润色不改变事实、证据、伏笔、认知状态或人物动机。

### 六、推荐人机分工

比较以下职责最适合由 GPT‑6 Pro 网页版、Codex、自动检查脚本或人类承担：

- 研究
- 概念竞争
- 规则 / 人物设计
- 宏观剧情
- 单场对抗推演
- ledger 维护
- 逻辑审计
- prose / voice 编辑
- Git 落盘与提交

给出分阶段会话策略：哪些可以同一会话，哪些必须新会话，何时冻结基线。

### 输出格式

最终输出一份完整 Markdown 报告，建议保存为：

`research/ai-fiction-engineering.md`

至少包含：

1. Executive Summary
2. 研究日期、范围、方法与限制
3. 长篇生成研究证据综述
4. 论文 / benchmark 对比矩阵
5. GitHub 项目实查矩阵
6. 主框架推荐与理由
7. 可复用、可借鉴、自研部分
8. 推荐 Story Bible / tracking schema
9. Agent / Skill pipeline
10. GPT‑6 Pro × Codex 分工
11. 文风与 deslop 方案
12. 自动校验与 review 方案
13. 实施阶段与迁移风险
14. 尚未解决的问题
15. 逐条带链接的来源

所有带时效性的仓库事实注明核查日期。停止条件：形成工程决策依据后结束，不进入原创剧情设计。

