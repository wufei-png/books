# Prompt 01：智斗剧情机制 Deep Research

## 使用方式

在一个全新的 Deep Research 会话中使用。不要同时上传小说概念，也不要让本轮替你设计原创故事。

## 提示词

你正在执行一项独立研究：建立可用于原创长篇小说的“智斗 / 心理战剧情设计理论”。

本轮只研究机制，不设计我的小说，不输出原创人物、世界观、逐章大纲或正文。最终报告将成为后续创作的固定理论基线。

### 研究目标

研究《死亡笔记》《LIAR GAME》《赌博默示录》《ONE OUTS》《噬谎者》《约定的梦幻岛》《Monster》等有代表性的智斗、博弈、心理战作品；可补充更适合的小说、影视、漫画或游戏，但总样本应保持聚焦。

不要做作品介绍或剧情复述。对每部作品只抽取可迁移的高层机制：

- 规则和约束如何产生策略空间；
- 信息不对称如何建立、变化和被利用；
- Truth、Evidence、Interpretation、Suspicion、Proof 如何区分；
- 人物如何从可观察行为推导隐藏信息；
- Bluff、Signaling、诱饵、可信承诺、主动暴露、反侦察如何工作；
- “我知道你知道……”的多层推理何时有效、何时只是作者炫技；
- 角色猜到真相后为什么仍可能无法证明或获胜；
- 阶段性胜利如何伴随可追踪的成本；
- 如何升级对抗而不只是扩大事件规模；
- 反转如何做到意外、可复盘且公平；
- 人物价值观、风险偏好、盲点和社会关系如何改变策略；
- 哪些失败来自规则、信息、资源或判断，而非角色突然降智。

### 来源要求

优先级：

1. 作者、编辑、出版社、制作方的一手访谈；
2. 学术论文、博弈论 / 叙事学研究；
3. 官方设定或可靠出版资料；
4. 高质量创作者分析；
5. 普通二手文章仅作为补充。

对关键结论给出可访问来源，并明确区分：事实、创作者自述、研究结论、你的推论、创作建议。不要以 SEO 文章作为核心证据。避免长段引用，优先准确转述。

### 必须建立的形式模型

#### 1. Rule Ledger

至少定义：硬规则、软规则、公开规则、隐藏规则、角色已知规则、例外、交互、揭示状态、违反代价。说明何时规则复杂度已经超过读者可承受范围。

#### 2. Truth / Evidence / Proof 模型

严格区分真相、线索、证据、解释、怀疑、证明。说明证据强度、来源可靠性、保管链、可访问者和可替代解释应如何记录。

#### 3. Character Knowledge State

为每个重要事实设计离散状态：

`knows / strongly_infers / suspects / unknown / falsely_believes`

不要默认使用没有校准依据的 confidence float。说明状态转移需要什么观察或证据。

#### 4. Reader Knowledge State

区分作者真相、POV 已知、其他角色已知、读者已知、读者可合理推导、刻意误导。说明公平隐藏与作者作弊的边界。

#### 5. Move / Countermove

至少包含：Actor、Goal、Available Information、Beliefs、Assumptions、Resources、Constraints、Action、Observable Signals、Intended Inference、Actual Inference、Countermove、Cost、Evidence Delta、Knowledge Delta、Reader Delta。

#### 6. Promise / Foreshadow

至少包含：Setup、Promise、Clue、Misdirection、Payoff、Deadline、Status。建立重大反转的 Fairness Audit。

### 对比矩阵

为研究样本建立机制矩阵，至少比较：

- 核心冲突形式
- Rules / Constraints
- Information Asymmetry
- Hidden Information
- Character Knowledge / False Belief
- Bluff / Signaling
- Evidence / Proof
- Counterplay
- Stakes / Cost
- Reversal
- Foreshadowing
- Reader vs Character Information
- Escalation
- Motivation
- Failure Mechanism

矩阵后必须做跨作品归纳，不能把表格本身当结论。

### 最终必须回答

1. 顶级智斗成立的最小结构是什么？
2. 如何检查“角色凭什么想到这一步”？
3. 如何检查对手是否存在显然更优的行动？
4. 如何让聪明角色合理犯错？
5. 如何设计可持续 20–40 万字而不会枯竭的对抗？
6. 如何控制规则解释负担？
7. 公平反转的必要条件和常见伪装是什么？
8. 哪些机制最容易被 LLM 写坏，为什么？

### 输出格式

最终输出一份完整 Markdown 报告，建议保存为：

`research/mind-game-design.md`

报告至少包含：

1. Executive Summary
2. 研究范围、日期、方法与限制
3. 样本选择理由
4. 跨作品机制对比矩阵
5. 智斗的最小形式模型
6. Rule Ledger 设计
7. Truth / Evidence / Proof 模型
8. Character / Reader Knowledge 模型
9. Move / Countermove 模型
10. Foreshadow / Fairness 模型
11. 对抗升级与长期可持续性
12. 人物驱动的策略选择
13. 常见失败模式与反例
14. 可直接用于创作的检查清单
15. 可机器化审计的字段建议
16. 尚未解决的问题
17. 带链接的来源清单

停止条件：完成理论和检查系统后结束。不得继续进入原创小说概念设计。

