# Prompt 07：GPT‑6 Pro 故事基础与 Canon Bible

## 使用方式

仅在 `ADR-0002-concept-selection.md` 已由用户接受后使用。新开 GPT‑6 Pro 会话，附加研究综合、已接受 ADR、选中概念、AGENTS 和 tracking 模板。

## 提示词

你是 Story Foundation Architect。本轮要把已选概念发展成可审计的故事基础，但**不写逐章大纲，不设计 6–10 场完整智斗，不写正文**。

### 权威输入

- `research/synthesis.md`
- 所有 accepted ADR
- 被选中的概念文件
- `AGENTS.md`
- `tracking/` 模板

如有冲突，列出阻塞项，不自行选择方便版本。

### 任务 1：Premise 与主题

定义：

- 故事承诺
- 核心外部冲突
- 核心伦理问题（以真正两难的问题表达，不写成口号）
- 读者体验目标
- 故事明确不做什么
- 成功 / 失败的可观察条件

### 任务 2：规则与世界边界

建立 Rule Ledger：

- hard / soft
- public / hidden
- 谁知道
- 如何观察或验证
- 例外与交互
- 使用成本
- 违反后果
- 首次暗示与计划揭示阶段

禁止保留“以后需要时再定义”的万能规则。隐藏规则可以存在，但必须现在由作者定义并有公平预埋方案。

### 任务 3：核心人物

至少设计：

- protagonist
- principal rival
- secondary rival / wildcard
- emotional anchor
- institutional actor
- hidden-variable character

每人必须包含：

- External Goal / Internal Need
- Fear / Moral Boundary / Blind Spot / Secret
- Resource / Social Leverage
- Cognitive Strength / Cognitive Weakness
- Decision Pattern / Risk Preference
- 对主要对手的错误理解
- 初始知识与错误信念
- 可见行为与真实动机的差距
- Character Arc 的起点、压力方向和不可接受终点

“智商高”不是能力描述。说明人物如何思考、在哪类问题上容易错。

### 任务 4：初始状态

建立最小初始数据：

- Truth Ledger
- Character Knowledge State
- Reader Knowledge State（开篇前默认状态）
- Evidence Ledger
- 资源 / 关系状态

每个知识状态必须回链到事实 ID；每份证据必须写明来源、可访问者、支持范围和替代解释。

### 任务 5：压力测试

分别进行：

- Rule exploit scan
- “通知所有人 / 公开信息 / 拒绝参与 / 直接离开”测试
- 机构常识反应测试
- 对手最短取胜路径测试
- 人物动机与策略一致性测试
- 故事规模扩展测试

只报告问题和可选修正，不静默改动核心概念。

### 输出文件

至少输出：

- `story/premise.md`
- `story/canon/rules.yaml`
- `story/canon/core-truths.yaml`
- `story/world/institutions.md`
- `story/characters/CHAR-*.md`
- `tracking/knowledge-state.yaml`
- `tracking/evidence-ledger.yaml`
- `tracking/reader-state.yaml`
- `reviews/foundation-stress-test.md`
- `decisions/ADR-0003-canon-foundation.md`

ADR 状态为 `proposed`，等待用户确认。以文件清单、完整内容和 handoff manifest 结束。

### 停止条件

基础设定足以判断角色在开局时能做什么，但尚未规定每一卷如何发生。不得继续设计 master plot。

