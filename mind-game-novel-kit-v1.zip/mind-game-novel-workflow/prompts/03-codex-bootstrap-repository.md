# Prompt 03：让 Codex 初始化 / 校正仓库

## 使用方式

在本地或已连接 Git 仓库的 Codex 会话中使用。若已解压本 starter kit，要求 Codex保留现有骨架并补齐缺失项。

## 提示词

请把当前目录初始化或校正为“AI 辅助高质量长篇智斗小说”的 Git 工作仓库。

### 输入

如果存在以下文件，先完整读取：

- `research/mind-game-design.md`
- `research/ai-fiction-engineering.md`
- `AGENTS.md`
- `docs/gate-checklist.md`

研究文件是来源材料，不得改写其正文；若格式或元数据有问题，以附录形式记录。

### 目标目录

至少保留或建立：

```text
research/
decisions/
story/
  canon/
  characters/
  world/
  outline/
  campaigns/
  chapters/
tracking/
reviews/
style/
schemas/
templates/
prompts/
docs/
```

### 必须完成

1. 检查工作树与现有文件，绝不覆盖不相关用户修改。
2. 建立 README、AGENTS、阶段门和 handoff 约定。
3. 建立空的 machine-readable tracking 模板，但不要凭空填入小说 canon。
4. 为 truth、knowledge、evidence、foreshadowing、move 定义稳定 ID 规则。
5. 明确权威文件顺序和 canon 变更流程。
6. 如已存在两份研究报告，验证文件存在、标题、执行日期与来源区段；不要评价创作内容。
7. 运行可行的 Markdown / YAML / JSON 基础校验。
8. 输出变更摘要与建议 commit；除非我明确授权，不要 push 或改写 Git 历史。

### ID 规则

建议：

- Truth：`TRUTH-0001`
- Rule：`RULE-0001`
- Evidence：`EVID-0001`
- Knowledge event：`KNOW-0001`
- Move：`MOVE-0001`
- Foreshadow：`FORESH-0001`
- Campaign：`CAMP-01`
- Character：`CHAR-001`
- Decision：`ADR-0001`

ID 一旦进入已提交的 canon，不因排序变化而重编号。

### 禁止事项

- 不创建原创人物或剧情。
- 不根据常识补齐缺失 canon。
- 不安装 Oh Story 或其他框架，除非工程研究已经明确选择且我授权实施。
- 不提交大型生成物、缓存或隐私数据。
- 不自动创建公开远端仓库。

### 完成标准

仓库可被下一轮 GPT‑6 Pro 会话通过有限文件集理解；Codex 能够检查引用、格式与阶段门；任何聊天中产生的新事实都必须经过文件化和 commit 才成为权威。

