# Prompt 11：Codex 落盘、验证与提交

## 使用方式

把 GPT‑6 Pro 的正式文件 bundle / handoff 放入当前工作区后，在连接真实 Git 仓库的 Codex 中使用。把方括号变量替换为本轮信息。

## 提示词

请将 `[HANDOFF_PATH_OR_ATTACHED_BUNDLE]` 整合进当前仓库，并以 `[EXPECTED_BASE_COMMIT_OR_TAG]` 为基线执行阶段门 `[GATE_ID]`。

本轮是仓库整合与验证，不是创作任务。除非我明确授权，禁止擅自补写剧情、修复 canon 或重解释模型输出。

### 1. 预检

- 读取 `AGENTS.md`、阶段门、本轮 handoff 和所有目标文件。
- 检查当前工作树，区分用户已有改动与本轮输入。
- 验证当前 HEAD 是否符合预期基线；若不符合，报告而不是重置。
- 列出将新增、替换、仅审查的文件。

### 2. 安全落盘

- 只写 handoff 明确列出的文件。
- 保留 UTF‑8、Markdown 结构和稳定 ID。
- 如果输出包含同一路径的多个版本，停止并报告冲突。
- 如果输出要改 locked canon 却没有 accepted ADR，拒绝写入该部分。
- 不覆盖用户未提交的重叠改动。

### 3. 机械验证

至少执行：

- Markdown 文件与链接路径存在性检查；
- YAML / JSON / JSONL 语法检查；
- 稳定 ID 唯一性；
- 跨文件引用目标存在；
- 必填字段存在；
- handoff 中声明的文件与实际变更一致；
- 无明显占位符：`TBD`、`TODO`、`???`（若有意保留，必须进入 unresolved list）。

### 4. 语义审计

只报告，不擅自修复：

- 新 knowledge 是否由可访问 observation / evidence 触发；
- evidence 是否有来源、访问者、保管链与支持范围；
- reader state 是否意外获得作者真相；
- move 是否引用当时不存在的资源或规则；
- payoff 是否回链 setup；
- 本轮是否越过规定停止条件。

### 5. 阶段门结论

输出 `PASS / PASS WITH RECORDED DEBT / FAIL`：

- `PASS`：所有 blocker / major 问题为零，机械验证通过。
- `PASS WITH RECORDED DEBT`：仅存在明确记录且不影响下一阶段的 moderate / minor 问题。
- `FAIL`：任何 blocker、major、格式失败、canon 未授权修改或基线冲突。

失败时保留可审查的工作树，不提交，不回滚用户改动，并生成 `reviews/gate-<id>-failure.md`。

### 6. Commit

只有在我已授权提交且阶段门通过时：

- 显示简洁 diff 统计；
- 使用 `[COMMIT_MESSAGE]`；
- 不 push；
- 不改写历史；
- 如 `[TAG_NAME]` 非空且门完全通过，再创建该标签。

### 最终报告

列出：

- 变更文件
- 机械验证结果
- 语义 finding
- 阶段门结论
- commit / tag（若创建）
- 尚未解决问题
- 下一会话应附加的最小文件集

