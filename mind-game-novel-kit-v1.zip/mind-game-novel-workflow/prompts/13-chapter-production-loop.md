# Prompt 13：正式逐章生产循环

## 使用方式

每章一个受控循环。可以由同一写作会话完成相邻 1–2 章，但 reviewer 必须独立。不要一次要求整卷正文。

## A. Scene Planner（GPT‑6 Pro）

请为 `CHAPTER_ID` 制定 scene plan。读取当前 commit 的 canon、相关 campaign、上一章 ending state、tracking 和 Style Bible。

对每个 scene 输出：

- Scene ID / POV / 时间地点
- entering truth / knowledge / evidence / resource state
- visible goal / hidden goal
- conflict / choice / cost
- observable actions
- information released / withheld
- evidence created / changed
- reader inference target
- exit state
- continuity constraints

不得写正式正文。若 campaign 逻辑不足，停止并报告，不用场景细节补洞。

## B. Narrative Writer（新的或干净上下文的 GPT‑6 Pro）

依据已批准 scene plan 和 Style Bible 写本章正文。允许改变句子、动作细节与节奏；禁止改变 scene outcome、canon、证据、伏笔、人物认知或新增规则。

正文中不要插入 ledger 标签。以具体行动、物件、对话和有限心理活动呈现策略。不要在转折后立即替读者总结意义。

## C. 独立 Reviewer

分别检查：

1. Logic / causality
2. Knowledge state / POV leakage
3. Evidence / proof
4. Character behavior / voice
5. Reader information / fairness
6. Prose / rhythm / AI tells

每个 finding 给出位置、问题、影响和最小修复边界。Reviewer 不直接改稿。

## D. Revision

作者会话只处理 accepted finding。每项修复后说明是否影响其他 scene、tracking 或 foreshadow；若影响 canon，停止并走 ADR。

## E. Minimal Deslop

只处理：过度解释、模板转折、重复总结、同义堆叠、无意义环境描写、平均句长、人物同声。不得添加“更文学”的新比喻来替换每个问题，也不得改动事实与策略。

## F. Canon Commit（Codex）

Codex 执行：

- 写入 `story/chapters/CHAPTER_ID.md`
- 更新 truth / knowledge / evidence / reader / foreshadow tracking
- 运行 G7 checklist
- 生成 handoff
- 通过后提交：`chapter: complete CHAPTER_ID`

未通过则只提交 review（若用户需要保留），不把该章标记为 canon。

