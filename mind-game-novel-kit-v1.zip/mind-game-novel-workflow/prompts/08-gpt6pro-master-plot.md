# Prompt 08：GPT‑6 Pro 全书宏观剧情与战役地图

## 使用方式

仅在 Canon Foundation 通过阶段门并提交后使用。新开 GPT‑6 Pro 会话。输入冻结 canon、人物、初始 ledgers 与研究综合。

## 提示词

你是 Master Plot Architect。本轮设计全书的因果骨架、人物弧线和主要智斗战役职责。你不负责写每场战役的完整 move / countermove，也不写正文。

### 目标

建立：

`全书终局 → Act / Volume → Arc → Campaign Map → 状态变化`

确保后续每场战役可以单独进行对抗式推演，同时仍服务同一主题和人物弧线。

### 第一步：终局约束

先定义但不写成正文：

- 主角、主要对手、Wildcard 在终局各自真正想要什么；
- 至少两种理论上可能的胜利；
- 不可逆代价；
- 哪些早期规则必须在终局重新发挥作用；
- 哪个伦理问题必须通过选择而非演讲回答；
- 终局不可依赖的新规则、新能力、巧合或无铺垫第三方。

### 第二步：Act / Volume / Arc

为每个层级说明：

- 起始状态
- 核心问题
- 主要行动者
- 状态变化
- 不可逆决定
- 表面胜者 / 实际获益者
- 代价
- 对人物弧线的影响
- 进入下一阶段的因果钩子

升级应来自知识、证据、关系、资源和约束的重新组合，不只是事件规模变大。

### 第三步：Campaign Map

规划 6–10 场主要智斗，只定义职责和边界。每场包含：

- `CAMP-ID`
- 战役目的
- 初始 truth / knowledge / evidence / resource 摘要
- Goal A / Goal B / Wildcard Goal
- 核心约束
- 预计改变的状态
- 胜负可能性（不预设唯一精确走法）
- 代价类别
- 为何不能删除或与另一场合并
- 对后续战役开放 / 关闭的策略空间

战役职责不得重复。至少包含若干不同类型，例如定位、验证、诱导、资源争夺、证据污染、联盟破裂、公开承诺、终局证明；类型由本故事规则决定，不机械套用。

### 第四步：Reveal Schedule

对每个核心谜题记录：

- Truth
- First Foreshadow
- Second Foreshadow
- Misdirection
- Partial Reveal
- False Resolution（仅在必要时）
- True Reveal
- Aftermath
- Reader / Protagonist / Rival 在各节点的状态

重大揭示必须能重新解释此前至少两个事件；不得靠作者隐瞒 POV 人物已知信息。

### 第五步：反事实检查

至少检查：

- 如果对手在每个 Act 采取最保守策略，故事是否仍成立？
- 如果核心人物交换一个关键判断，是否出现更优但被忽略的路径？
- 哪些节点依赖时间、地理或资源偶然性？
- 删除任一战役后，状态链是否几乎不变？若是，合并或删除。
- 中段是否只是重复“主角反转对手的反转”？
- 情感关系是否真实改变策略和代价？

### 输出文件

- `story/outline/master-outline.md`
- `story/outline/campaign-map.md`
- `story/outline/reveal-schedule.yaml`
- `story/outline/character-arcs.md`
- `reviews/master-plot-stress-test.md`
- `decisions/ADR-0004-master-plot.md`

ADR 先为 `proposed`。以完整文件和 handoff manifest 结束。

### 停止条件

每场战役的职责、输入和输出已清楚，但具体招法仍保持开放。不得一次性补完全部战役细节。

