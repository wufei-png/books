# Handoff Manifest

- Session ID:
- Source stage:
- Based on commit / tag:
- Target gate:
- Date:

## Files to add

| Path | Purpose | Complete content included? |
|---|---|---|

## Files to replace

| Path | Reason | Canon impact |
|---|---|---|

## Stable IDs added or changed

| ID | Type | Change |
|---|---|---|

## Decisions made

- Decision:
  - Basis:
  - Alternatives rejected:

## Canon declarations

- Canon changed: yes / no
- Rules changed: yes / no
- Character knowledge changed: yes / no
- Reader knowledge changed: yes / no
- Evidence changed: yes / no
- Foreshadow / promise changed: yes / no

## Explicit non-changes

列出本轮承诺没有改变的核心事实、规则和 outcome。

## Unresolved issues

| ID | Severity | Issue | Blocks next stage? |
|---|---|---|---|

## Validation requested from Codex

- [ ] Format and syntax
- [ ] ID uniqueness and references
- [ ] Canon authorization
- [ ] Knowledge transitions
- [ ] Evidence chain
- [ ] Foreshadow / payoff links
- [ ] Stage stop condition

## Minimal context for next session

- `<path>`

