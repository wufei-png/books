# ADR-XXXX: Decision title

- Status: proposed
- Date: YYYY-MM-DD
- Deciders:
- Based on commit / tag:

## Context

## Decision

## Evidence and rationale

## Alternatives considered

## Consequences

### Benefits

### Costs and risks

## Files and stable IDs affected

## Migration / backfill

## Validation and regression checks

## Human approval

## Revisit triggers

