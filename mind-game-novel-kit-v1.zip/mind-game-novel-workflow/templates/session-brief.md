# Session Brief

- Session ID:
- Stage / Gate:
- Model / Mode:
- Date:
- Repository commit or tag:
- Role for this session:

## Authoritative inputs

- `<path>`

## Objective

用一句可验收的话描述本轮结果。

## Allowed changes

- `<path or category>`

## Forbidden changes

- Canon / rules / outcomes not explicitly listed above

## Required outputs

- `<path>`

## Validation criteria

- [ ]

## Stop conditions

- 输入冲突或缺失
- 需要修改 locked canon
- 已达到本阶段输出，禁止自动进入下一阶段

