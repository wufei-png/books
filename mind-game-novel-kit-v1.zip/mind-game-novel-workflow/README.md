# 智斗长篇小说：GPT‑6 Pro × Codex 工作流

这是一套“研究先行、Git 为唯一事实源、GPT‑6 Pro 负责高阶设计、Codex 负责结构化落盘与审计”的长篇智斗小说 starter kit。

## 最推荐的分工

| 工具 / 会话 | 主要职责 | 不应承担 |
|---|---|---|
| Deep Research 会话 1 | 提炼智斗作品的可迁移机制 | 设计你的原创小说 |
| Deep Research 会话 2 | 调研 AI 长篇工程、框架与 Skills | 为了迁就工具而决定剧情 |
| GPT‑6 Pro 网页版 | 概念竞争、人物/规则设计、宏观剧情、逐场智斗推演 | 直接成为仓库的隐式事实源 |
| Codex | 建仓、写入文件、校验 schema、追踪矛盾、生成 diff、提交 | 未经批准擅自补写或修改 canon |
| 独立 GPT‑6 Pro 审稿会话 | 站在对手、逻辑、证据或读者视角攻击方案 | 替原设计辩护 |

## 推荐顺序

1. 现在初始化仓库并提交本套骨架。
2. 分别运行 `prompts/01`、`prompts/02`，把研究报告保存到 `research/`。
3. 提交并打标签 `research-baseline-v1`。
4. 运行 `prompts/04`，只综合研究，不开始设计故事。
5. 分别运行概念生成、独立红队筛选、故事基础、宏观剧情。
6. 每一场主要智斗使用一个独立 GPT‑6 Pro 会话；不要一次生成 6–10 场完整战役。
7. 每轮输出先由 Codex 写入临时文件、检查，再提交。
8. 全局逻辑通过后，才做文风校准与逐章生产。

完整步骤见 [`docs/operation-guide.md`](docs/operation-guide.md)。阶段门见 [`docs/gate-checklist.md`](docs/gate-checklist.md)。

## 快速开始

```bash
git init -b main
git add .
git commit -m "chore: bootstrap mind-game novel workflow"
```

完成两份研究后：

```bash
git add research/
git commit -m "research: freeze mind-game and AI-fiction baselines"
git tag research-baseline-v1
```

建议使用私有仓库，至少在小说发表前不要公开核心设定、反转和完整 Story Bible。

## 核心原则

- Git 文件而非聊天记忆是权威事实源。
- 每个阶段使用新会话；同一个 ChatGPT Project 只用于共享稳定文件。
- 创作者、审稿者、仓库整合者分离。
- “猜对”“怀疑”“证据”“可证明”必须分开。
- 角色只能使用当时可获得的信息。
- 重大反转必须能回溯到已有规则和至少两处有效铺垫。
- 不使用看似精确但无校准依据的 confidence float。
- 不让模型在一次会话里同时设计、审查、辩护和修复同一方案。

## 提示词索引

| 文件 | 使用位置 | 产物 |
|---|---|---|
| `01-research-mind-game-mechanics.md` | Deep Research | `research/mind-game-design.md` |
| `02-research-ai-fiction-engineering.md` | Deep Research | `research/ai-fiction-engineering.md` |
| `03-codex-bootstrap-repository.md` | Codex | 初始化 / 校正仓库 |
| `04-gpt6pro-synthesize-research.md` | GPT‑6 Pro | 研究综合与设计约束 |
| `05-gpt6pro-concept-generation.md` | GPT‑6 Pro | 原创概念候选，不评选 |
| `06-gpt6pro-concept-red-team.md` | 独立 GPT‑6 Pro | 红队与概念选择 |
| `07-gpt6pro-foundation-bible.md` | GPT‑6 Pro | 人物、规则、世界基础 |
| `08-gpt6pro-master-plot.md` | GPT‑6 Pro | 全书宏观剧情与战役地图 |
| `09-gpt6pro-campaign-loop.md` | 每场一个 GPT‑6 Pro 新会话 | 单场智斗完整设计 |
| `10-gpt6pro-global-red-team.md` | 独立 GPT‑6 Pro | 全局对抗式审计 |
| `11-codex-ingest-validate-commit.md` | Codex | 落盘、验证、提交 |
| `12-gpt6pro-style-calibration.md` | GPT‑6 Pro | Style Bible 与试写校准 |
| `13-chapter-production-loop.md` | GPT‑6 Pro + Codex | 逐章生产闭环 |

