# 实际操作指南

## 结论

可以，而且这是推荐主线：**研究 1、2 形成固定基线 → Git 冻结 → GPT‑6 Pro 分阶段设计 → Codex 审计并提交**。

但有一个小调整更稳：仓库骨架现在就初始化；研究 1、2 完成后再做第一个“有内容的基线提交”和标签。这样提示词、研究原文、后续设计与审查都有完整版本历史。

```mermaid
flowchart TD
    A["初始化私有 Git 仓库"] --> B1["研究 1：智斗机制"]
    A --> B2["研究 2：AI 长篇工程"]
    B1 --> C["冻结 research-baseline-v1"]
    B2 --> C
    C --> D["GPT-6 Pro：概念与故事基础"]
    D --> E["GPT-6 Pro：宏观剧情"]
    E --> F["逐场智斗设计"]
    F --> G["独立红队审查"]
    G --> H["文风校准与逐章写作"]
```

## 一、一次性准备

### 1. 初始化仓库

解压本套件后，在目录中执行：

```bash
git init -b main
git add .
git commit -m "chore: bootstrap mind-game novel workflow"
```

如需远端备份，创建一个**私有** GitHub 仓库后再添加 remote。未发表小说的核心诡计、反转和全文不建议放在公开仓库。

### 2. 创建一个 ChatGPT Project

建议名称：`智斗长篇小说（设计）`。

Project 用于集中放稳定背景文件，但不要把 Project 的隐式记忆当作 canon。每个阶段仍开启新 chat，并在开头明确本轮允许读取、允许修改、必须输出的文件。

官方 OpenAI 文档说明，ChatGPT 可以在项目或文件夹上下文中使用其中的文件，并在 ChatGPT 与 Codex 工作流之间选择；这适合作为会话入口，但本方案仍以 Git 文件作为权威源：<https://learn.chatgpt.com/docs/app>。

### 3. 模型与模式

- 研究 1、2：使用 Deep Research，允许联网和来源追踪。
- 故事设计：使用 GPT‑6 Pro 网页版；默认不联网，只读取冻结研究与 canon。
- 独立审查：另开 GPT‑6 Pro 新会话，不给原设计会话的辩护过程。
- 落盘与提交：使用 Codex 读取真实工作树。

若界面允许推理强度选择，故事结构、智斗设计和全局审查使用高质量 / 深度推理档；格式化、搬运和普通校验交给 Codex。

## 二、阶段 R：两份独立研究

### R1：智斗机制

在新 Deep Research 会话运行 `prompts/01-research-mind-game-mechanics.md`。

要求最终只形成研究报告，不设计你的小说。保存为：

`research/mind-game-design.md`

### R2：AI 长篇工程

在另一个新 Deep Research 会话运行 `prompts/02-research-ai-fiction-engineering.md`。

要求实际检查论文、仓库、许可证、活跃度和关键文件。保存为：

`research/ai-fiction-engineering.md`

R1 与 R2 可以并行。二者互不引用，避免“先有工具结论再影响理论研究”。

### R-Gate：研究冻结

让 Codex 执行以下检查：

- 两份报告是否完整、带来源、能区分事实与推论；
- R1 是否没有偷偷开始设计原创小说；
- R2 是否给出可执行的复用 / fork / 自研判断，而非项目简介；
- 是否列出不确定项与版本日期。

然后提交：

```bash
git add research/
git commit -m "research: freeze mind-game and AI-fiction baselines"
git tag research-baseline-v1
```

此后如果研究需要更新，新增版本或勘误，不要静默覆盖导致后续设计失去依据。

## 三、阶段 S：只做研究综合

新建 GPT‑6 Pro 会话，上传 / 附加：

- `research/mind-game-design.md`
- `research/ai-fiction-engineering.md`
- `prompts/04-gpt6pro-synthesize-research.md`

本轮禁止创造人物、世界或剧情。输出：

- `research/synthesis.md`
- `decisions/ADR-0001-creative-engineering-workflow.md`
- `schemas/` 或 tracking 字段建议（若研究支持）

让 Codex 用 `prompts/11-codex-ingest-validate-commit.md` 落盘。通过后提交：

```bash
git commit -m "design: synthesize research into creative constraints"
```

## 四、阶段 C：概念锦标赛，而不是一次拍脑袋

### C1：概念生成

新 GPT‑6 Pro 会话运行 `prompts/05-gpt6pro-concept-generation.md`。

它只负责产生差异明显的候选和自证材料，**不得选冠军**。输出：

- `story/concepts/candidates.md`
- `reviews/concept-similarity-audit.md`

### C2：独立红队与选择

换一个全新 GPT‑6 Pro 会话，运行 `prompts/06-gpt6pro-concept-red-team.md`。它可以：

- 选择一个；
- 要求两个候选重做后再比；
- 判定全部不合格。

不要强迫模型“必须选一个”。通过后提交并标记：

```bash
git commit -m "design: select original novel concept"
git tag concept-selected-v1
```

## 五、阶段 F：冻结故事基础

运行 `prompts/07-gpt6pro-foundation-bible.md`，只确定：

- premise 与主题问题；
- 世界边界、硬规则、软规则和例外；
- 核心人物的欲望、盲点、资源、底线与认知差异；
- 机构、资源、风险与核心谜题；
- 初始 truth / knowledge / evidence 状态。

本轮不写逐章大纲，不追求炫技反转。完成后由独立会话做规则漏洞和人物行为审查，通过再标记：

```bash
git commit -m "canon: establish story foundation v1"
git tag canon-foundation-v1
```

## 六、阶段 P：宏观剧情与逐场智斗分开

### P1：宏观剧情

运行 `prompts/08-gpt6pro-master-plot.md`。只设计：

- 全书终局与不可逆代价；
- Act / Volume / Arc；
- 6–10 场主要智斗的职责、输入状态和输出状态；
- Reveal Schedule 的宏观节点；
- 人物弧线与外部冲突如何互相驱动。

不要在一个会话里写完每场智斗的全部 move / countermove。

### P2：逐场智斗

对每个 `CAMPAIGN-ID` 新开一个 GPT‑6 Pro 会话，重复使用 `prompts/09-gpt6pro-campaign-loop.md`。

建议顺序：

1. 先设计该战役的初始状态、目标和约束；
2. 站在 A 视角提出首轮可行行动；
3. 站在 B 视角找最优反制；
4. 让第三视角审计双方是否使用了不可知信息；
5. 更新 evidence、knowledge、reader state；
6. 只有通过局部门，才进入下一场战役。

一场战役一个 chat 的好处是：对手不会被前一个会话的作者偏好“驯服”，也避免全书后段被上下文压缩。

完成全部战役后：

```bash
git commit -m "plot: complete adversarial campaign architecture"
git tag plot-logic-v1
```

## 七、阶段 A：全局红队

新 GPT‑6 Pro 会话运行 `prompts/10-gpt6pro-global-red-team.md`。把 reviewer 分成独立视角：

- Logic：因果、规则、时间线；
- Opponent：对手是否存在显然更优行动；
- Knowledge：越权信息；
- Evidence：怀疑是否被误写成证明；
- Fairness：揭晓是否公平；
- Character：策略是否来自人物而非作者；
- Reader：读者能否理解、能否被公平误导。

审稿会话只出 finding，不直接改 canon。作者会话另开，逐项接受 / 拒绝 / 延后，并为接受项创建 ADR 或 fix commit。

## 八、阶段 W：文风校准后再写正文

运行 `prompts/12-gpt6pro-style-calibration.md`：

- 先定 Style Bible 与人物 idiolect；
- 选一个不泄漏终局的高压场景；
- 写 1500–2500 字样章；
- 独立审查逻辑、信息量、人物声线、AI 痕迹；
- 只修订一次并记录差异。

不要在逻辑尚未通过时用“文笔润色”掩盖结构问题。

正式逐章时使用 `prompts/13-chapter-production-loop.md`。每章都执行：

`Scene Plan → Draft → Logic/Knowledge Audit → Voice Edit → Minimal Deslop → Canon Commit`

## 九、GPT‑6 Pro 与 Codex 的标准交接

每个 GPT‑6 Pro 会话都必须以一个 handoff 结束，格式见 `templates/handoff-manifest.md`：

- 要新增 / 替换的文件；
- 每个文件的完整内容；
- 新增与修改的稳定 ID；
- 做出的决定；
- 未解决问题；
- 下一阶段所需文件；
- 明确声明没有偷偷改动哪些 canon。

然后把 handoff 交给 Codex，运行 `prompts/11-codex-ingest-validate-commit.md`。Codex 先写入工作树并校验，只有通过阶段门才提交。

## 十、什么时候开新会话

必须开新会话：

- 研究 1 与研究 2；
- 概念生成与概念评选；
- 设计者与红队 reviewer；
- 每一场主要智斗；
- 全局审查；
- 正文写作者与最终独立读者。

可以沿用同一会话：

- 同一份文件的小范围澄清；
- reviewer 要求补充其证据；
- 一次修订中处理彼此强相关的 2–3 个 finding。

一旦会话开始引用“前面聊过但文件里没有”的事实，应停止并把该事实正式写入仓库；否则它不属于 canon。

## 十一、最重要的人工决策点

以下节点不建议自动化通过：

1. 最终概念选择；
2. 核心规则锁定；
3. 主角和主要对手的道德底线；
4. 最大反转与结局代价；
5. 是否接受会改写 canon 的审查建议；
6. 文风样章是否达到你愿意继续读的标准。

AI 可以给出有证据的建议，但这些决定会定义整本书的身份。

