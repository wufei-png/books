# Decisions

本目录保存 Architecture / Authorial Decision Records。任何会改变 locked canon、核心规则、人物底线、重大反转或工作流的决定都应有 ADR。

状态：

- `proposed`：模型或作者提出，尚未生效
- `accepted`：用户确认，成为权威
- `superseded`：被另一 ADR 明确替代
- `rejected`：保留记录但不执行

禁止模型自行把 `proposed` 改成 `accepted`。

