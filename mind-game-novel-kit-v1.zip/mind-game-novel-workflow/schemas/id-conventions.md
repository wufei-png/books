# Stable ID Conventions

| 类型 | 格式 | 示例 |
|---|---|---|
| Truth | `TRUTH-NNNN` | `TRUTH-0001` |
| Rule | `RULE-NNNN` | `RULE-0001` |
| Evidence | `EVID-NNNN` | `EVID-0001` |
| Knowledge event / state | `KNOW-NNNN` | `KNOW-0001` |
| Move | `MOVE-NNNN` | `MOVE-0001` |
| Foreshadow | `FORESH-NNNN` | `FORESH-0001` |
| Promise | `PROMISE-NNNN` | `PROMISE-0001` |
| Character | `CHAR-NNN` | `CHAR-001` |
| Campaign | `CAMP-NN` | `CAMP-01` |
| Scene | `SCENE-NNNN` | `SCENE-0001` |
| Chapter | `CH-NNN` | `CH-001` |
| Decision | `ADR-NNNN` | `ADR-0001` |
| Review finding | `FIND-YYYYMMDD-NNN` | `FIND-20260922-001` |

规则：

1. ID 只表达身份，不表达可变排序。
2. 已提交 ID 不回收、不重编号。
3. 删除使用 tombstone / status，而非把同一 ID 分配给新对象。
4. 引用使用 ID；文件重命名后更新索引，但不改变 ID。
5. 临时候选可使用 `CONCEPT-A` 等，在选定并进入 canon 后分配正式 ID。

