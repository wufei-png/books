# Tracking Schema

所有 ID 进入已提交 canon 后不可重编号。字段可随 ADR 增加，但不得无迁移说明改变含义。

## Truth entry

```yaml
id: TRUTH-0001
statement: "作者层面的客观事实"
valid_from: "故事时间或事件 ID"
valid_until: null
source: "canon 文件路径"
status: active
```

## Knowledge entry

```yaml
id: KNOW-0001
subject_id: CHAR-001
truth_id: TRUTH-0001
state: unknown
basis_evidence_ids: []
basis_move_ids: []
valid_from: "SCENE-0001"
valid_until: null
notes: ""
```

允许状态仅为：

- `knows`
- `strongly_infers`
- `suspects`
- `unknown`
- `falsely_believes`

`falsely_believes` 还需在 notes 或扩展字段记录其具体错误命题，不能只写“错了”。

## Reader state entry

字段与 knowledge 类似，但 `subject_id` 固定为 `READER`，并可使用：

- `revealed`
- `strongly_inferable`
- `weakly_inferable`
- `withheld_fairly`
- `misdirected`

## Evidence entry

```yaml
id: EVID-0001
description: "可观察对象或记录"
created_at: "事件 ID"
created_by: CHAR-001
truth_ids_supported: []
truth_ids_refuted: []
alternative_interpretations: []
custody: []
accessible_to: []
authenticity: verified
status: active
source_file: ""
```

`authenticity` 建议使用 `verified / plausible / disputed / forged / unknown`，不得把“支持某真相”误写成“足以证明某真相”。

## Foreshadow entry

```yaml
id: FORESH-0001
payoff_truth_id: TRUTH-0001
setup_scene_ids: []
misdirection_scene_ids: []
partial_reveal_scene_ids: []
payoff_scene_id: null
reader_interpretations_before_payoff: []
fairness_notes: ""
status: planned
```

## Promise entry

```yaml
id: PROMISE-0001
promise: "故事向读者或人物建立的明确期待"
setup_scene_id: SCENE-0001
deadline: "Act / Campaign / Chapter"
payoff_scene_id: null
status: open
```

## Resource / relationship

资源和关系必须有持有者、有效区间和变化事件。不要只维护当前值，否则无法审计某一历史节点人物能否使用它。

