# AGENTS.md

本仓库用于创作高密度、规则驱动、可复盘的原创智斗长篇小说。

## 权威顺序

出现冲突时，按以下顺序判断；禁止默默挑选方便的版本：

1. `story/canon/` 中已锁定 canon
2. `decisions/` 中已接受的决定记录
3. `tracking/` 中的 truth / knowledge / evidence / foreshadowing 状态
4. `story/outline/master-outline.md`
5. `story/campaigns/`
6. `story/chapters/` 的 scene plan
7. 正文草稿
8. 聊天记录、临时笔记和模型记忆

若高优先级文件彼此冲突，停止写作，在 `reviews/` 新建冲突报告，不得自行改 canon。

## 修改边界

- 研究报告原文只允许增加元数据或勘误附录，不得无痕改写。
- Canon 变更必须有 `decisions/ADR-XXXX-*.md`，写明原因、受影响文件、迁移办法。
- 审稿阶段只能报告问题；除非任务明确授权，不得直接修复。
- Prose edit / deslop 不得改变事实、证据、规则、伏笔、人物认知和场景结果。
- 不把作者知道的信息泄漏给 POV 人物、其他角色或读者。
- 不使用无来源的精确 confidence float；使用 `knows / strongly_infers / suspects / unknown / falsely_believes`。
- 不以“其实早已全部算到”代替可复盘的推理链。

## 每次变更前

1. 读取任务直接依赖的权威文件。
2. 列出允许修改与禁止修改的文件。
3. 检查当前工作树，保留用户未提交修改。
4. 若输入不完整，生成缺口清单；不要凭空补 canon。

## 每次变更后

1. 校验 YAML / JSON / JSONL 语法。
2. 检查 ID 唯一性和引用目标存在性。
3. 检查知识状态是否只由可观察事件更新。
4. 检查 evidence 的来源、保管链、可访问者和可证明范围。
5. 检查重大 payoff 是否已有 setup。
6. 在 handoff 中列出：修改文件、关键决定、未解决问题、下一阶段所需输入。

## Git 约定

- 一个阶段门一个提交；不要把研究、canon 修改和正文润色混在同一提交。
- 推荐前缀：`research:`、`design:`、`canon:`、`plot:`、`audit:`、`style:`、`chapter:`、`fix:`。
- 不自动 push，不改写历史，不强推。
- 通过阶段门后再打标签；失败审查只提交 review，不推进标签。

