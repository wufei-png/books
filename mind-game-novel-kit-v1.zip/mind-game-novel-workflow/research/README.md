# Research

权威研究文件：

- `mind-game-design.md`：智斗剧情机制研究
- `ai-fiction-engineering.md`：AI 长篇工程与工具研究
- `synthesis.md`：仅在两份报告冻结后生成的综合约束

研究报告需写明执行日期、范围、方法、限制和来源。更新时保留版本依据；不要为了配合后续剧情静默改写研究结论。

