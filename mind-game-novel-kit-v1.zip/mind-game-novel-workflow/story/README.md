# Story

| 目录 | 职责 |
|---|---|
| `canon/` | 已锁定规则与作者真相 |
| `characters/` | 人物 Bible；一个主要人物一个稳定 ID 文件 |
| `world/` | 机构、地点、社会反应与资源边界 |
| `outline/` | master outline、campaign map、reveal schedule、人物弧线 |
| `campaigns/` | 一场主要智斗一个文件 |
| `chapters/` | 已通过 G7 的章节正文及必要 scene plan |

聊天中的设定只有写入相应文件、通过阶段门并提交后才成为 canon。

